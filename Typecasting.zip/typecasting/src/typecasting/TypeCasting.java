package typecasting;

public class TypeCasting {

	public static void main(String[] args) {
		// Implicit Type Casting 
        int intValue = 200;
        double doubleValue = intValue; // conversion from int to double

        System.out.println("Implicit Type Casting :");
        System.out.println("int value: " + intValue);
        System.out.println("double value: " + doubleValue);

        // Explicit Type Casting 
        double doubleNum = 12.34;
        int intNum = (int) doubleNum; // conversion from double to int

        System.out.println("\nExplicit Type Casting :");
        System.out.println("double value: " + doubleNum);
        System.out.println("int value: " + intNum);
    }

	}


